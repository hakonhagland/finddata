#! /bin/bash

cat dir/p1/p1.config
tree newdir
cat newdir/DEMO/DEMO.config
