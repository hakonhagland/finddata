#! /bin/bash

makedirs.pl
p.pl --prjroot=dir --outdir=newdir --mapfile=sample.txt
