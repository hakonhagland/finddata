#! /bin/bash


p.pl --prjroot=$input_file --outdir=$output_file --mapfile=$mapfile
